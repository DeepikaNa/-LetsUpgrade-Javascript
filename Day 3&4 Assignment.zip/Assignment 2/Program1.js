function ClickButton(){
    const img = document.getElementById("image"); 
    //const doc= img.innerHTML ="https://s3.r29static.com/bin/entry/ce2/x,80/2169674/image.jpg";
    src = "https://s3.r29static.com/bin/entry/ce2/x,80/2169674/image.jpg";
    const newUrl = "https://img.freepik.com/free-vector/queen-word-with-crown_97378-77.jpg?size=626&ext=jpg";
    img.src = newUrl;
}
function changeImage() {
    const pic = document.getElementById("image");
    const newUrl ="https://s3.r29static.com/bin/entry/ce2/x,80/2169674/image.jpg";
    pic.src = newUrl;
  }
  function ChangeOriginal() {
    const figure= document.getElementById("image");
    src = "https://img.freepik.com/free-vector/queen-word-with-crown_97378-77.jpg?size=626&ext=jpg";
    const newUrl ="https://cdn.pixabay.com/photo/2015/04/19/08/32/marguerite-729510__340.jpg";
    figure.src = newUrl;
  }
 

