// 4) Program to display only elements containing 'a' in them from a array
let input=prompt("enter size");
let a=new Array();
for(var i=0;i<input;i++)
{
	a[i]=prompt("enter the strings into array");
}
for(i=0;i<=input;i++)
{
   
   for(var j=0;j<(a[i].length);j++)
   {
      if(a[i][j]=='a')
	    {
	      console.log(a[i]);
		  break;
		} 
   }

}